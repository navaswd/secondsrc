import { combineReducers } from 'redux';
import { routerReducer } from 'react-router-redux';
import { reducer as formReducer } from 'redux-form';
import cartSummary from './reducers/cartSummary';

const rootReducer = combineReducers({
  cartSummaryState: cartSummary,
});

export default rootReducer;
