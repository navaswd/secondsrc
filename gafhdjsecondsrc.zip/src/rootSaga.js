import { cartSummaryWatcher } from './sagas/cartSummary';

export default function* rootWatchers() {
  yield [
    cartSummaryWatcher(),
  ];
}
