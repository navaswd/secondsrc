
import * as CARTSUMMARY from '../actionTypes/CartSummary';

const initialState = {
    cartSummaryData:[],
    isLoading: true
};

export default (state = initialState, action) => {

    switch (action.type) {
        case CARTSUMMARY.GET_CART_SUMMARY: {
            return {
                ...state,
                isLoading: true,
            };
        }

        case CARTSUMMARY.GET_CART_SUMMARY_SUCCESS: {
            return {
                ...state,
                isLoading: false,
                cartSummaryData: action.data
            };
        }

        case CARTSUMMARY.GET_CART_SUMMARY_FAILURE: {
            return {
                ...state,
                isLoading: false,
                error: action.error,
            };
        }

        case CARTSUMMARY.UPDATE_CART_SUMMARY: {
            return {
                ...state
            }
        }

        case CARTSUMMARY.UPDATE_CART_SUMMARY_SUCCESS: {
            return {
                ...state
            }
        }
        
        case CARTSUMMARY.UPDATE_CART_SUMMARY_FAILURE: {
            return {
                ...state
            }
        }

        case CARTSUMMARY.ADD_ITEM_CART_SUMMARY: {
            return {
                ...state
            }
        }

        case CARTSUMMARY.ADD_ITEM_CART_SUMMARY_SUCCESS: {
            return {
                ...state
            }
        }

        case CARTSUMMARY.ADD_ITEM_CART_SUMMARY_FAILURE: {
            return {
                ...state
            }
        }

        case CARTSUMMARY.REMOVE_ITEM_CART_SUMMARY: {
            return {
                ...state
            }
        }

        case CARTSUMMARY.REMOVE_ITEM_CART_SUMMARY_SUCCESS: {
            return {
                ...state
            }
        }

        case CARTSUMMARY.REMOVE_ITEM_CART_SUMMARY_FAILURE: {
            return {
                ...state
            }
        }
        
        default:
            return state;
    }
};
