import { put, takeLatest } from 'redux-saga/effects';
import envConfig from 'envConfig'; //eslint-disable-line
import * as CARTSUMMARY from '../actionTypes/cartSummary';
import * as cartActionCreators from '../actionCreators/cartSummary';
import { doGet } from '../utils/fetchWrapper';


export function* getCartSummary() {
  try {
    const response = yield doGet(envConfig.apiEndPoints.getCartSummary);
    yield put(cartActionCreators.getCartSummarySuccess(response.data));
  } catch (error) {
    yield put(cartActionCreators.getCartSummaryFailure(error));
  }
}

export function* updateCartSummary(action) {
  try {
    const response = yield doPut(envConfig.apiEndPoints.getCartSummary, action.data);
    yield put(cartActionCreators.updateCartSummarySuccess(response.data));
  } catch (error) {
    yield put(cartActionCreators.updateCartSummaryFailure(error));
  }
}

export function* cartSummaryWatcher() {
  yield [
    takeLatest(CARTSUMMARY.GET_CART_SUMMARY, getCartSummary),
    takeLatest(CARTSUMMARY.UPDATE_CART_SUMMARY, updateCartSummary)
  ];
}
